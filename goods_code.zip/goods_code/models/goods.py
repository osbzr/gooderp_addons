# -*- coding: utf-8 -*-
# Copyright 2018 上海开阖软件 ((http:www.osbzr.com).)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import models, fields
from odoo.tools.translate import _


class goods(models.Model):
    _name = "goods"

    code = fields.Char(
        string=_("编号"),
        required=False,
        translate=False,
        readonly=False
    )
